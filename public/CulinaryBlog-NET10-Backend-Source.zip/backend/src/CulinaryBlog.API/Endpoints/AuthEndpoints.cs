using System.Security.Claims;
using CulinaryBlog.Application.Features.Auth.Commands.GoogleLogin;
using CulinaryBlog.Application.Features.Auth.Commands.Login;
using CulinaryBlog.Application.Features.Auth.Commands.RefreshToken;
using CulinaryBlog.Application.Features.Auth.Commands.Register;
using CulinaryBlog.Application.Features.Auth.DTOs;
using MediatR;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace CulinaryBlog.API.Endpoints;

public static class AuthEndpoints
{
    public static RouteGroupBuilder MapAuthEndpoints(this RouteGroupBuilder group)
    {
        // FR-AUTH-001: Register
        group.MapPost("/register", Register)
            .WithName("Register")
            .WithSummary("Register new user (FR-AUTH-001) with Author role, auto-login tokens & queued welcome email")
            .Produces<AuthResponseDto>(StatusCodes.Status201Created)
            .ProducesProblem(StatusCodes.Status409Conflict)
            .ProducesValidationProblem(StatusCodes.Status422UnprocessableEntity);

        // FR-AUTH-002: Local Login
        group.MapPost("/login", Login)
            .WithName("Login")
            .WithSummary("Authenticate with email/password (FR-AUTH-002), token rotation & account lockout after 5 attempts")
            .Produces<AuthResponseDto>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status423Locked);

        // FR-AUTH-003: Google OAuth 2.0 Login
        group.MapPost("/google", GoogleLogin)
            .WithName("GoogleLogin")
            .WithSummary("Authenticate or auto-provision with Google OAuth 2.0 (FR-AUTH-003)")
            .Produces<AuthResponseDto>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status400BadRequest);

        // FR-AUTH-004: Token Refresh with Rotation & Reuse Detection
        group.MapPost("/refresh", RefreshToken)
            .WithName("RefreshToken")
            .WithSummary("Refresh access token with token rotation & paranoid reuse attack detection (FR-AUTH-004)")
            .Produces<AuthResponseDto>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized);

        // Profile endpoint
        group.MapGet("/me", GetCurrentUser)
            .WithName("GetCurrentUser")
            .WithSummary("Retrieve authenticated user profile claims")
            .Produces<UserDto>(StatusCodes.Status200OK)
            .RequireAuthorization();

        return group;
    }

    public static async Task<Results<Created<AuthResponseDto>, Conflict<ProblemDetails>, UnprocessableEntity<ProblemDetails>>> Register(
        [FromServices] ISender sender,
        [FromBody] RegisterCommand command)
    {
        var result = await sender.Send(command);

        if (!result.IsSuccess)
        {
            if (result.ErrorCode?.StartsWith("CONFLICT") == true)
            {
                return TypedResults.Conflict(new ProblemDetails
                {
                    Type = "https://tools.ietf.org/html/rfc9110#section-15.5.10",
                    Title = "Account Conflict",
                    Status = StatusCodes.Status409Conflict,
                    Detail = result.ErrorMessage
                });
            }

            return TypedResults.UnprocessableEntity(new ProblemDetails
            {
                Type = "https://tools.ietf.org/html/rfc9110#section-15.5.21",
                Title = "Registration Failed",
                Status = StatusCodes.Status422UnprocessableEntity,
                Detail = result.ErrorMessage
            });
        }

        return TypedResults.Created("/api/v1/auth/me", result.Value!);
    }

    public static async Task<Results<Ok<AuthResponseDto>, UnauthorizedHttpResult, StatusCodeHttpResult>> Login(
        [FromServices] ISender sender,
        [FromBody] LoginCommand command)
    {
        var result = await sender.Send(command);

        if (!result.IsSuccess)
        {
            if (result.ErrorCode == "ACCOUNT_LOCKED")
            {
                // HTTP 423 Locked (RFC 4918)
                return TypedResults.StatusCode(StatusCodes.Status423Locked);
            }

            return TypedResults.Unauthorized();
        }

        return TypedResults.Ok(result.Value!);
    }

    public static async Task<Results<Ok<AuthResponseDto>, BadRequest<ProblemDetails>>> GoogleLogin(
        [FromServices] ISender sender,
        [FromBody] GoogleLoginCommand command)
    {
        var result = await sender.Send(command);

        if (!result.IsSuccess)
        {
            return TypedResults.BadRequest(new ProblemDetails
            {
                Title = "Google Authentication Failed",
                Status = StatusCodes.Status400BadRequest,
                Detail = result.ErrorMessage
            });
        }

        return TypedResults.Ok(result.Value!);
    }

    public static async Task<Results<Ok<AuthResponseDto>, UnauthorizedHttpResult>> RefreshToken(
        [FromServices] ISender sender,
        [FromBody] RefreshTokenCommand command)
    {
        var result = await sender.Send(command);

        if (!result.IsSuccess)
        {
            return TypedResults.Unauthorized();
        }

        return TypedResults.Ok(result.Value!);
    }

    public static Ok<UserDto> GetCurrentUser(ClaimsPrincipal principal)
    {
        var idStr = principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? Guid.Empty.ToString();
        _ = Guid.TryParse(idStr, out var id);

        var email = principal.FindFirstValue(ClaimTypes.Email) ?? "";
        var name = principal.FindFirstValue("fullName") ?? principal.FindFirstValue(ClaimTypes.Name) ?? "";
        var userName = principal.FindFirstValue(ClaimTypes.Name) ?? "";
        var roles = principal.FindAll(ClaimTypes.Role).Select(r => r.Value).ToList();

        return TypedResults.Ok(new UserDto(id, name, email, userName, null, roles));
    }
}
