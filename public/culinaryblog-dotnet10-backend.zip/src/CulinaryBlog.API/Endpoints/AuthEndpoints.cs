using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using CulinaryBlog.Application.Common.Interfaces;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace CulinaryBlog.API.Endpoints;

public record LoginRequest(string Email, string Password);
public record AuthResponse(string Token, string FullName, string Email, string Role);

public static class AuthEndpoints
{
    public static RouteGroupBuilder MapAuthEndpoints(this RouteGroupBuilder group)
    {
        group.MapPost("/login", Login)
            .WithName("Login")
            .WithSummary("Authenticate user and issue JWT bearer token")
            .Produces<AuthResponse>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized);

        group.MapGet("/me", GetCurrentUser)
            .WithName("GetCurrentUser")
            .WithSummary("Get authenticated caller claims and profile details")
            .Produces<AuthResponse>(StatusCodes.Status200OK)
            .RequireAuthorization();

        return group;
    }

    public static async Task<Results<Ok<AuthResponse>, UnauthorizedHttpResult>> Login(
        [FromServices] IApplicationDbContext db,
        [FromServices] IConfiguration config,
        [FromBody] LoginRequest request)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.Email == request.Email.Trim() && !u.IsDeleted);
        if (user == null)
        {
            return TypedResults.Unauthorized();
        }

        // Issue JWT token
        var jwtKey = config["Jwt:SecretKey"] ?? "super-secret-key-that-is-at-least-32-chars-long-123456";
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.FullName),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role)
        };

        var token = new JwtSecurityToken(
            issuer: config["Jwt:Issuer"] ?? "CulinaryBlog.API",
            audience: config["Jwt:Audience"] ?? "CulinaryBlog.Client",
            claims: claims,
            expires: DateTime.UtcNow.AddDays(7),
            signingCredentials: creds
        );

        var tokenStr = new JwtSecurityTokenHandler().WriteToken(token);

        return TypedResults.Ok(new AuthResponse(tokenStr, user.FullName, user.Email, user.Role));
    }

    public static Ok<AuthResponse> GetCurrentUser(ClaimsPrincipal principal)
    {
        var email = principal.FindFirstValue(ClaimTypes.Email) ?? "";
        var name = principal.FindFirstValue(ClaimTypes.Name) ?? "";
        var role = principal.FindFirstValue(ClaimTypes.Role) ?? "Guest";

        return TypedResults.Ok(new AuthResponse("", name, email, role));
    }
}
