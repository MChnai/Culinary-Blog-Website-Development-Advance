using CulinaryBlog.Domain.Common;

namespace CulinaryBlog.Domain.Entities;

public class ApplicationUser : BaseEntity
{
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Role { get; set; } = "Author"; // "Admin", "Author", "Reader"
    public string? AvatarUrl { get; set; }
    public string? Bio { get; set; }

    public ICollection<Recipe> Recipes { get; set; } = new List<Recipe>();
}
